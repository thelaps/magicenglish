<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Field' );


	class TribeField extends Tribe__Field {

	}
