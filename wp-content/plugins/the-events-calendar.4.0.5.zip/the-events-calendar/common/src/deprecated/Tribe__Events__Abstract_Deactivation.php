<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Abstract_Deactivation.php' );

abstract class Tribe__Events__Abstract_Deactivation extends Tribe__Abstract_Deactivation {}
